from meteo_de_muy_cold.api_main import api_main

__all__ = ['api_main']